<?php 
define('BASE_URL', '/daw2/Epic_Eats');
?>