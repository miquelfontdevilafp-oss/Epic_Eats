<?=$usuari->getId() . ' ';?>
<?=$usuari->getNomUsuari() . ' ';?>
<?=$usuari->getContrasenya() . ' ';?>
<?=$usuari->getNom() . ' ';?>
<?=$usuari->getCognoms() . ' ';?>
<?=$usuari->getCorreu() . ' ';?>
<?=$usuari->getRol() . ' ';?>
<?=$usuari->getTelefon() . ' ';?>
